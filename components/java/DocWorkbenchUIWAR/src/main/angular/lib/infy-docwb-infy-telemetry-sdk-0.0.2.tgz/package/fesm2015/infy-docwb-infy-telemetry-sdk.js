import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { __awaiter } from 'tslib';
import { v4 } from 'uuid';
import { start, end, interact, impression, log, feedback, resetActor, resetContext, initialize } from '@project-sunbird/telemetry-sdk';

class UserSessionManager {
    constructor({ sessionTimeout, checkUserActive }) {
        this.sessionTimeout = sessionTimeout;
        this.checkUserActive = checkUserActive;
        this.userActiveFlag = true;
        this.eventAction = this.updateUserExpireTime.bind(this);
        this.windowEventListener();
        this.startInterval();
    }
    windowEventListener() {
        window.addEventListener("mousemove", this.eventAction);
        window.addEventListener("scroll", this.eventAction);
        window.addEventListener("keydown", this.eventAction);
    }
    startInterval() {
        this.updateUserExpireTime();
        setInterval(() => {
            const expiredTime = parseInt(localStorage.getItem("session_expire_time"), 10);
            if (expiredTime < Date.now() && this.userActiveFlag) {
                console.log("User is now considered inactive!");
                this.userActiveFlag = false;
            }
        }, 1000);
    }
    updateUserExpireTime() {
        if (this.sessionMonitor) {
            clearTimeout(this.sessionMonitor);
        }
        this.sessionMonitor = setTimeout(() => {
            const currentTime = Date.now();
            const sessionExpiration = currentTime + this.sessionTimeout * 1000;
            localStorage.setItem("session_expire_time", String(sessionExpiration));
        }, 300);
        if (this.checkUserActive && !this.userActiveFlag) {
            console.log("User has resumed activity!");
            this.userActiveFlag = true;
            this.checkUserActive();
        }
    }
}

class TelemetrySunbirdConfig {
}
class ProducerData {
}
class TelemetryStartEventDetails {
}
class TelemetryImpressionEventDetails {
}
class TelemetryImpressionVisitsEvent {
}
class TelemetryInteractEventDetails {
}
class TelemetryEndEventDetails {
}
class TelemetryLogEventDetails {
}
class TelemetryFeedbackEventDetails {
}
class TelemetryActor {
}
class TelemetryContextData {
}
class TelemetryObject {
}
class TelemetryEventOptions {
}

class TelemetryService {
    constructor() {
        this.TIMEOUT_IN_SEC = 900;
        console.log("InfyTelemetrySdk -> TelemetryService Started");
    }
    sample() {
        return "Text from InfyTelemetrySdk -> TelemetryService";
    }
    setProviderImplementation(provider, config) {
        if (provider == "SUNBIRD") {
            if (!config.sid || !config.activeSessionPeriodLimit) {
                config.activeSessionPeriodLimit = this.TIMEOUT_IN_SEC;
            }
            this.userSessionManager(config);
            this.initialize(config);
        }
    }
    start(config, contentId, contentVer, data, options) {
        return __awaiter(this, void 0, void 0, function* () {
            this.resetContext(config);
            console.log('Start Event Data->', data);
            if (!config.uid)
                this.resetActor(config.uid);
            this.config = config;
            this.contentId = contentId;
            this.contentVer = contentVer;
            let currentTime = Date.now();
            this.modifyContextOptions(options);
            start(this.config, this.contentId, this.contentVer, data, options, currentTime);
        });
    }
    end(data, options) {
        let currentTime = Date.now();
        this.modifyContextOptions(options);
        end(data, options, currentTime);
    }
    interact(data, options) {
        let currentTime = Date.now();
        this.modifyContextOptions(options);
        interact(data, options, currentTime);
    }
    impression(data, options) {
        let currentTime = Date.now();
        this.modifyContextOptions(options);
        impression(data, options, currentTime);
    }
    log(data, options) {
        let currentTime = Date.now();
        this.modifyContextOptions(options);
        log(data, options, currentTime);
    }
    feedback(data, options) {
        let currentTime = Date.now();
        this.modifyContextOptions(options);
        feedback(data, options, currentTime);
    }
    resetActor(actorName) {
        let actor = { "id": actorName || 'anonymous', "type": 'User' };
        resetActor(actor);
    }
    resetContext(context) {
        let context_ = new TelemetryContextData();
        context_.pdata = context.pdata;
        context_.env = context.env;
        context_.sid = context.sid;
        context_.channel = context.channel;
        context_.cdata = context.cdata;
        // context_.rollup = context.rollup;
        resetContext(context_);
    }
    initialize(config) {
        initialize(config);
    }
    ;
    userSessionManager(config) {
        let userSessionManagerObj = new UserSessionManager({
            sessionTimeout: config.activeSessionPeriodLimit,
            checkUserActive: () => {
                config.sid = this.fetchSessionIdentifier(config);
                this.resetContext(config);
            },
        });
        config.sid = this.fetchSessionIdentifier(config);
    }
    fetchSessionIdentifier(config) {
        let sid = localStorage.getItem('session_id');
        let expirationTime = parseInt(localStorage.getItem('session_expire_time'), 10);
        if (!sid || !expirationTime || expirationTime < Date.now()) {
            console.log('sessionId is either not present or no longer valid; generating new id!');
            // creating new session id since the sid is not present or existing sid expired
            config.sid = v4();
            console.log('Newly created sid ->', config.sid);
            // setting the new sid in localstorage 
            localStorage.setItem('session_id', config.sid);
            //updating the expiration time in localstorage
            let setExpirationTime = Date.now() + config.activeSessionPeriodLimit * 1000;
            localStorage.setItem('session_expire_time', setExpirationTime.toString());
            // resetting the config using resetContext method in @project-sunbird/telemetry-sdk
            this.resetContext(config);
            // returning the newly generated sid
            return config.sid;
        }
        console.log('sessionId in local storage is still valid; returning the same sessionId!');
        return sid;
    }
    modifyContextOptions(options) {
        if (!options || !options.context)
            return;
        const contextData = options.context;
        const configProperties = Object.keys(this.config);
        Object.keys(contextData).forEach(key => {
            if (configProperties.includes(key)) {
                this.config[key] = contextData[key];
            }
        });
    }
}
TelemetryService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: TelemetryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
TelemetryService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: TelemetryService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: TelemetryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class InfyTelemetrySdkModule {
}
InfyTelemetrySdkModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: InfyTelemetrySdkModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
InfyTelemetrySdkModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: InfyTelemetrySdkModule });
InfyTelemetrySdkModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: InfyTelemetrySdkModule, providers: [TelemetryService], imports: [[]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.2.16", ngImport: i0, type: InfyTelemetrySdkModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [],
                    exports: [],
                    providers: [TelemetryService]
                }]
        }] });

/*
 * Public API Surface of infy-telemetry-sdk
 */

/**
 * Generated bundle index. Do not edit.
 */

export { InfyTelemetrySdkModule, TelemetryService };
//# sourceMappingURL=infy-docwb-infy-telemetry-sdk.js.map
