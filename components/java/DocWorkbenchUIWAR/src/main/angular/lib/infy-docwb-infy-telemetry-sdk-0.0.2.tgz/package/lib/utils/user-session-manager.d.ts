declare class UserSessionManager {
    private sessionTimeout;
    private checkUserActive;
    private userActiveFlag;
    private eventAction;
    private sessionMonitor;
    constructor({ sessionTimeout, checkUserActive }: {
        sessionTimeout: any;
        checkUserActive: any;
    });
    private windowEventListener;
    private startInterval;
    private updateUserExpireTime;
}
export default UserSessionManager;
