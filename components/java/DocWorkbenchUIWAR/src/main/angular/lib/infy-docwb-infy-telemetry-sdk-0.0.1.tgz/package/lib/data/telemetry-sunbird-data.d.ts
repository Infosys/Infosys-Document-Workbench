export declare class TelemetrySunbirdConfig {
    'pdata': ProducerData;
    'channel': string;
    'uid': string;
    'did'?: string;
    'authtoken': string;
    'env': string;
    'sid'?: string;
    'batchsize'?: number;
    'mode'?: string;
    'host'?: string;
    'endpoint'?: string;
    'tags'?: Array<string>;
    'cdata'?: Array<string>;
}
export declare class ProducerData {
    'id': string;
    'ver': string;
    'pid': string;
}
export declare class TelemetryStartEventDetails {
    'type': string;
    'pageid'?: string;
    'mode'?: string;
    'dspec'?: {};
    'uaspec'?: {};
    'duration'?: number;
}
export declare class TelemetryImpressionEventDetails {
    'type': string;
    'subtype'?: string;
    'pageid': string;
    'uri': string;
    'visits'?: Array<TelemetryImpressionVisitsEvent>;
}
export declare class TelemetryImpressionVisitsEvent {
    'objid': string;
    'objtype': string;
    'objver'?: string;
    'section'?: string;
    'index': string | number;
}
export declare class TelemetryInteractEventDetails {
    'id': string;
    'type': string;
    'subtype'?: string;
    'pageid'?: string;
    'extra'?: {};
    'target'?: string;
    'plugin'?: string;
}
export declare class TelemetryEndEventDetails {
    'pageid'?: string;
    'duration'?: string;
    'type': string;
    'mode'?: string;
    'summary'?: Array<{}>;
}
export declare class TelemetryActor {
    'id': string;
    'type': string;
}
export declare class TelemetryContextData {
    'channel': string;
    'env': string;
    'pdata'?: {};
    'sid'?: string;
    'did'?: string;
    'cdata'?: Array<{}>;
}
export declare class TelemetryObject {
    'id': string;
    'type': string;
    'ver'?: string;
}
export declare class TelemetryEventOptions {
    'context'?: TelemetryContextData;
    'object'?: TelemetryObject | any;
    'actor'?: TelemetryActor;
    'tags'?: Array<string>;
    'runningEnv'?: string;
}
//# sourceMappingURL=telemetry-sunbird-data.d.ts.map