import * as i0 from "@angular/core";
export declare class InfyTelemetrySdkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InfyTelemetrySdkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InfyTelemetrySdkModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InfyTelemetrySdkModule>;
}
//# sourceMappingURL=infy-telemetry-sdk.module.d.ts.map