import { TelemetryEndEventDetails, TelemetryImpressionEventDetails, TelemetryInteractEventDetails, TelemetryStartEventDetails, TelemetrySunbirdConfig, TelemetryContextData, TelemetryEventOptions } from '../data/telemetry-sunbird-data';
import * as i0 from "@angular/core";
export declare class TelemetryService {
    provider: string;
    config: TelemetrySunbirdConfig;
    contentId: string;
    contentVer: string;
    private TIMEOUT_IN_SEC;
    constructor();
    sample(): string;
    setProviderImplementation(provider: string, config: any): void;
    start(config: any, contentId: string, contentVer: string, data: TelemetryStartEventDetails, options?: TelemetryEventOptions): Promise<void>;
    end(data: TelemetryEndEventDetails, options?: TelemetryEventOptions): void;
    interact(data: TelemetryInteractEventDetails, options?: TelemetryEventOptions): void;
    impression(data: TelemetryImpressionEventDetails, options?: TelemetryEventOptions): void;
    resetActor(actorName: string): void;
    resetContext(context: TelemetryContextData): void;
    initialize(config: {}): void;
    private userSessionManager;
    private fetchSessionIdentifier;
    private modifyContextOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<TelemetryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TelemetryService>;
}
//# sourceMappingURL=telemetry.service.d.ts.map