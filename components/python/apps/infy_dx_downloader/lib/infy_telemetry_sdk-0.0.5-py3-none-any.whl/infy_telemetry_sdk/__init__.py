# ===============================================================================================================#
# Copyright 2022 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

"""## 1. Introduction

`infy_telemetry_sdk` is a python library to provide api to post telemetry data to service.

It's also a python wrapper for the following non-python libraries:

- infy-telemetry-sdk.jar


## 2. Version History

- **V 0.0.1** _(2022-06-17)_
  - Initial version as a python wrapper for `infy-telemetry-sdk.jar.
  - APIs exposed are `event log`.


## 3. Prerequisite

The following software should be installed in your local system.

- Python 3.6 or above
- infy-telemetry-sdk.jar
"""
