# ===============================================================================================================#
# Copyright 2022 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import os
import enum
import json
from pathlib import Path
import glob
import subprocess
import logging
import base64
from datetime import datetime
import copy

CONFIG_PARAM_DICT = {
    "to_dir": None,
    "hocr_file": None,
    "dpi": 300,
    "pages": [],
    "bboxes": [[]],
    "water_mark": None,
    "page_dimension": {
        "width": 0,
        "height": 0
    }
}

JAR_GENERAL_ERROR_MSG = 'Error occurred in main method'

# Module variable to set jar home path. E.g. C:/ProgramFiles/InfyDocwbTelemetry
docwb_telemetry_jar_home = ''


class TelemetryEvent(enum.Enum):
    """Enum class to TelemetryEvent
    Args:
        enum (str): Enum Action
    """
    LOG = "LOG"
    START = "START"
    END = "END"


class LogLevel(enum.Enum):
    """Enum class for Log Level

    Args:
        enum (str): Log Level
    """
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    FATAL = "FATAL"


EVENT_DATA: dict = {
    "type": "",
    "logLevel": "",
    "message": "",
    "pageId": "",
    "params": {}
}

PRODUCER_DATA: dict = {
    "id": "",
    "pid": "",
    "ver": ""
}

TELEMETRY_CONFIG_DATA = {
    "configData": {},
    "hostUrl": "",
    "username": "",
    "password": "",
    "disableSSLValidation": False,
    "authtoken": {
        "tokenName": "",
        "tokenExpireDtm": "",
        "tokenValue": ""
    }
}

C_DATA: dict = {
    "type": "",
    "id": ""
}

C_DATA_LIST = [C_DATA]


class DocwbTelemetry:
    """Class for Telemetry events"""

    def __init__(self, telemetry_config_data: TELEMETRY_CONFIG_DATA, producer_data: PRODUCER_DATA) -> None:
        """Init method

        Args:
            telemetry_config_data (TELEMETRY_CONFIG_DATA): Required to initialize the telemetry jar
            producer_data (PRODUCER_DATA): Required. Event producer data dictionary.
        """
        self.__telemetry_config_data = telemetry_config_data
        self.__producer_data = producer_data

    def execute(self, event: TelemetryEvent, event_data: EVENT_DATA, context_data_list: C_DATA_LIST = [],
                additional_config_param: dict = None):
        """Execute telemetry event data post.

        Args:
            event (TelemetryEvent): Required. Event type
            event_data (EVENT_DATA): Required. Event data dictionary.
            context_data_list ([C_DATA_LIST]): Optional. Context Data.
        Returns:
            [json]
        """
        telemetry_config_data = copy.deepcopy(self.__telemetry_config_data)
        run_command = ['java', '-jar', self.__get_tool_path()]
        run_command += ["--event", event.value]
        run_command += ["--event-data",
                        self.__convert_dict_to_base64_str(event_data)]
        run_command += ["--producer-data",
                        self.__convert_dict_to_base64_str(self.__producer_data)]
        stdout, stderr = None, None
        if context_data_list:
            context = telemetry_config_data.get(
                'configData', {}).get('context', {})
            if context:
                context['cdata'] = context.get('cdata', []) + context_data_list
            else:
                stderr = "context prop is missing in config data"

        run_command += ["--telemetry-config-data",
                        self.__convert_dict_to_base64_str(
                            self.__update_telemetry_config_authtoken_dtm(telemetry_config_data, additional_config_param))]
        if not stderr:
            sub_process = subprocess.Popen(
                run_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr = sub_process.communicate()
        if (not stdout and stderr) or (JAR_GENERAL_ERROR_MSG in stdout):
            logger = logging.getLogger(os.path.basename(__file__))
            logger.error(stderr)
            return None, stderr

        return json.loads(stdout), None

    def __convert_dict_to_base64_str(self, data_dict):
        # string -> bytes -> base64 encode -> decode encoded bytes -> encoded str
        encoded = base64.b64encode(json.dumps(data_dict).encode()).decode()
        return encoded

    def __update_telemetry_config_authtoken_dtm(self, telemetry_config_data, additional_config_param):
        authtoken = telemetry_config_data.pop('authtoken')
        if authtoken:
            authtoken['tokenExpireDtm'] = str(datetime.now())
            # checking `<`,`>` that is because of master config hints of "tokenValue": "<tenant_id updated internally>"
            if not authtoken['tokenValue'] or "<" in authtoken['tokenValue'] or ">" in authtoken['tokenValue']:
                authtoken['tokenValue'] = additional_config_param.get(
                    'telemetry').get('tenant_id')
            telemetry_config_data['authorization'] = self.__convert_dict_to_base64_str(
                authtoken)
        return telemetry_config_data

    def __json_to_base64_str(self, json_object):
        return base64.b64encode(json.dumps(json_object).encode('utf-8'))

    def __get_tool_path(self):
        JAR_FILE_FORMAT = "infy-telemetry-sdk-*.jar"
        tool_path = str(
            f"{docwb_telemetry_jar_home}/{JAR_FILE_FORMAT}")
        format_convert_jars = glob.glob(tool_path)
        if format_convert_jars:
            tool_path = str(Path(format_convert_jars[0]).resolve())
        else:
            err_msg = f"Could not find any jar file format of '{JAR_FILE_FORMAT}' in "
            err_msg += f"path '{docwb_telemetry_jar_home}'"
            raise Exception(err_msg)
        return tool_path
