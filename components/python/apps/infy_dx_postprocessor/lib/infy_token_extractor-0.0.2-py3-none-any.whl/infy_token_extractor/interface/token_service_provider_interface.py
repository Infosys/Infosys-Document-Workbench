# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import abc
import logging
import sys

TOKEN_RES_STRUCTURE = {
    "name": "",
    "values": [],
    "error": None
}


class TokenServiceProviderInterface(metaclass=abc.ABCMeta):
    """Interface class"""
    @ classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'extract_tokens') and
                callable(subclass.extract_tokens) or
                NotImplemented)

    def __init__(self, logger: logging.Logger = None,
                 log_level: int = None):
        self.__set_logger(logger, log_level)

    @ abc.abstractmethod
    def extract_tokens(self, text: str) -> TOKEN_RES_STRUCTURE:
        """Implement logic to extract required tokens from given text.

        Args:
            text (str): Plain text.

        Raises:
            NotImplementedError

        Returns:
            TOKEN_RES_STRUCTURE
        """
        raise NotImplementedError

    def __set_logger(self, logger, log_level):
        self.logger = logger
        LOG_FORMAT = logging.Formatter(
            '%(asctime)s.%(msecs)03d %(levelname)s [%(threadName)s] [%(module)s] [%(funcName)s:%(lineno)d] %(message)s')
        if logger is None:
            log_level = logging.WARNING if log_level is None else log_level
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(log_level)
            # Add sysout hander
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(log_level)
            console_handler.setFormatter(LOG_FORMAT)
            self.logger.addHandler(console_handler)
            self.logger.info('log initialized')
        else:
            hndlr = self.logger.handlers[0]
            hndlr.setFormatter(LOG_FORMAT)
            self.logger.info('Formatter updated')
