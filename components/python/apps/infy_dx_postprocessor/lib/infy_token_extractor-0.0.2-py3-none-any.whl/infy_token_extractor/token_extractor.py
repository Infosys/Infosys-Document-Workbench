# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import copy

from infy_token_extractor.interface.token_service_provider_interface import \
    TokenServiceProviderInterface

TOKEN_RES_STRUCTURE = {
    "tokens": [
        {"name": "", "values": []}
    ],
    "error": None
}


class TokenExtractor():
    """Class to get tokens from given text"""

    def __init__(self):
        pass

    def get_tokens(self, text: str, token_service_providers: [TokenServiceProviderInterface]) -> TOKEN_RES_STRUCTURE:
        """API to extract all provider based tokens from given `text`.

        Args:
            text (str): Plain text
            token_service_providers ([TokenServiceProviderInterface]): List of providers to extract tokens from given text.

        Returns:
            TOKEN_RES_STRUCTURE: Returns dictionary containing all extracted Tokens.
        """

        res_structure_dict = copy.deepcopy(TOKEN_RES_STRUCTURE)
        try:
            if not token_service_providers:
                res_structure_dict['error'] = "valid provider(s) are required"
                return res_structure_dict
            res_structure_dict['tokens'] = []
            for provider in token_service_providers:
                res_token_dict = provider.extract_tokens(text)
                if res_token_dict.pop('error', None) is None:
                    res_structure_dict['tokens'].append(res_token_dict)
        except Exception as e:
            res_structure_dict['error'] = e.args[0]
        return res_structure_dict
