# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import copy
import logging
import re
from datetime import datetime

from dateutil import parser
from infy_token_extractor.interface.token_service_provider_interface import (
    TOKEN_RES_STRUCTURE, TokenServiceProviderInterface)

CONFIG_PARAMS_DICT = {
    "base_date_string": None,
    "base_date_format": "%m/%d/%Y"
}


class DateTokenServiceProvider(TokenServiceProviderInterface):
    """Implementation of TokenServiceProviderInterface for Date token extraction"""

    def __init__(self, logger: logging.Logger = None, log_level: int = None, config_params_dict: CONFIG_PARAMS_DICT = None):
        """constructor

        Args:
            logger (logging.Logger, optional): logger object. Defaults to None.
            log_level (int, optional): log level. Defaults to None.
        """
        super(DateTokenServiceProvider, self).__init__(logger, log_level)
        self.__config_params_dict = config_params_dict if config_params_dict else CONFIG_PARAMS_DICT

    def extract_tokens(self, text: str) -> TOKEN_RES_STRUCTURE:
        """Extracts Date pattern configured matched tokens from given text.

        Args:
            text (str): Plain Text

        Returns:
            TOKEN_RES_STRUCTURE: Date Object containing extracted `raw_text` and it's `parser_text`(%m/%d/%Y).
        """
        token_res_struct = copy.deepcopy(TOKEN_RES_STRUCTURE)
        try:
            token_res_struct['name'] = 'date'
            token_res_struct['values'] = self.__extract_tokens(text)
        except Exception as e:
            token_res_struct['error'] = e.args[0]

        return token_res_struct

    def get_date_regex_pattern_config(self) -> str:
        """Configure all date format regex pattern here to match in give string.
        Can be extended to override the current logic.
        """
        reg_ex = r"\s*[a-zA-Z]+\s*[0-9]+\s*[,.]{1}[.]*\s*[0-9]+|\s*[0-9]+\s*[ /]+\s*[0-9a-zA-Z]+\s*[ /]+\s*[0-9]+|\s*[0-9]+\s*[ -]+\s*[0-9a-zA-Z]+\s*[ -]+\s*[0-9]+"
        return reg_ex

    def clean_text(self, text: str) -> str:
        """Configure pattern to clean given text, if any. Can be extended to override the current logic.

        Args:
            text (str): Plani text passed in `extract_tokens`

        Returns:
            str: Pattern cleaned text.
        """
        # Logic 1: replace unusual date delimiter
        text = text.replace("\n", ";")
        text = text.replace("_", "")
        text = re.sub(r"([0-9]+):([0-9]+)[-/.]([0-9]+)", "\\1/\\2/\\3", text)
        text = re.sub(r"([0-9]+)-([0-9]+)[.]([0-9]+)", "\\1/\\2/\\3", text)
        text = re.sub(r"\D-([0-9]+)-([0-9]+)", "", text)
        text = re.sub(r"([0-9]+)\s+([0-9]+)/([0-9]+)/([0-9]+)",
                      "\\2/\\3/\\4", text)
        # pls dont change the order
        text = text.replace(" -", "-")
        text = text.replace("- ", "-")
        text = re.sub(
            r"([0-9]+)-([0-9]{1})\s([0-9]{1})-([0-9]+)", "\\1/\\2\\3/\\4", text)
        text = re.sub(r"\w+\s+[0-9]+[/]{1}[0-9]+\s", "", text)
        text = re.sub(r"([a-zA-z]+)\s*([0-9]+)\s*([a-zA-z]+)", "\\1 \\3", text)
        text = re.sub(r"([0-9]+)(\s+)([0-9]+)", "\\1;\\3", text)
        # text = re.sub(r"(\w),(\w)", "\\1, \\2", text)
        return text

    def parse_incomplete_year(self, tokens: list) -> dict:
        """Method to handle incomplete year century. Can be extended to override the current logic.

        Args:
            date_parse_obj (dict): Contains `raw_text` and `parser_text`.
            date_format_text (str): Date filtered text.

        Returns:
            dict/None: Century modified date_parse_obj else None
        """
        def _parse_incomplete_year(token_data):
            date_str = token_data['parser_text']
            date_year = date_str.split("/")[2].strip()
            current_year = datetime.today().year
            current_year_prefix = str(current_year)[:2]
            if not (date_year in token_data['raw_text']):
                if int(f"{current_year_prefix}00")+100 > current_year < int(date_year):
                    temp_date_str = date_str.split("/")
                    token_data[
                        'parser_text'] = f"{temp_date_str[0]}/{temp_date_str[1]}/{int(current_year_prefix)-1}{temp_date_str[2][-2:]}"
                elif int(date_year) > current_year:
                    token_data = None
            return token_data
        final_date_list = []
        for token_data in tokens:
            token_data = _parse_incomplete_year(token_data)
            if token_data:
                final_date_list.append(token_data)

        return final_date_list

    def __extract_tokens(self, text: str):
        date_format_text = self.__findall_date_format_str(
            self.clean_text(text))
        date_parse_list = self.__parse_all_dates(date_format_text)
        extracted_dates = self.parse_incomplete_year(date_parse_list)
        return extracted_dates

    def __findall_date_format_str(self, text):
        text = re.findall(self.get_date_regex_pattern_config(), text.lower())
        text = ";".join(text)
        return text

    def __parse_all_dates(self, text):
        dates_found = []
        try:
            current_base_date_format = "%m/%d/%Y"
            current_date_as_base = datetime.today().strftime(current_base_date_format)
            base_date_str = self.__config_params_dict[
                'base_date_string'] if self.__config_params_dict.get('base_date_string', None) else current_date_as_base
            base_date_format = self.__config_params_dict['base_date_format'] if self.__config_params_dict.get(
                'base_date_format', None) else current_base_date_format

            base_date = datetime.strptime(base_date_str, base_date_format)
            for date_text in text.split(";"):
                date_text = date_text.strip()
                try:
                    result = parser.parse(date_text, default=base_date)
                    date_str = datetime.strftime(result, base_date_format)
                    date_year = date_str.split("/")[2].strip()
                    if date_year.startswith("0"):
                        continue
                    dates_found.append(
                        {"raw_text": date_text, "parser_text": date_str})
                except Exception:
                    pass
        except Exception as e:
            self.logger.error(e)
        return dates_found
