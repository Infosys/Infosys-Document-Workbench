# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
import os
import logging
import urllib3
from infy_ocr_parser.interface.data_service_provider_interface import \
    DataServiceProviderInterface
from infy_ocr_parser.internal.common_util import CommonUtil


class GenericOcrDataServiceProvider(DataServiceProviderInterface):
    """Implementation of DataServiceProvider for Generic OCR"""
    API_POST_FILE_UPLOAD = "/api/v1/file/upload"
    API_POST_PARSER_LINES_STRUCTURE = "/api/v1/ocr/parser/line"
    API_POST_PARSER_WORD_STRUCTURE = "/api/v1/ocr/parser/word"
    API_POST_PARSER_PAGEBBOX = "/api/v1/ocr/parser/pagebbox"

    RESPONSE_LINE_STRUCTURE_JSON_FORMAT = {
        "id": "string",
        "page": 0,
        "text": "string",
        "bbox": [0, 0, 0, 0],
        "scalingFactor": [0, 0],
        "words": [{"id": "string",
                   "page": 0,
                   "text": "string",
                   "bbox": [0],
                   "scalingFactor":[0],
                   "conf": "string_of_number"
                   }]
    }
    RESPONSE_WORD_STRUCTURE_JSON_FORMAT = {
        "id": "string",
        "page": 0,
        "text": "string",
        "bbox": [0, 0, 0, 0],
        "scalingFactor": [0, 0],
        "conf": "string_of_number"
    }
    RESPONSE_PAGE_BBOX_JSON_FORMAT = {
        "page": 0,
        "bbox": [0, 0, 0, 0],
    }

    def __init__(self, base_url: str, logger: logging.Logger = None,
                 log_level: int = None):
        """Creates an instance of GenericOcrDataServiceProvider class

        Args:
            logger (logging.Logger, optional): logger object. Defaults to None.
            log_level (int, optional): log level. Defaults to None.
        """
        super(GenericOcrDataServiceProvider,
              self).__init__(logger, log_level)
        self._ocr_file_data_list = []
        self._ocr_file_id_list = []
        self._http = self.__get_http_handle()
        self._base_url = base_url

    def init_provider_inputs(self, doc_list: list):
        """Method used to load the list input ocr files to given provider.

        Args:
            doc_list (list): OCR file list
        """
        if doc_list:
            for ocr_file in doc_list:
                # call api to get file id's
                # e.g.self._ocr_file_id_list=["7346candck","de6cv8b"]
                with open(ocr_file, "rb") as reader:
                    image_data = reader.read()
                api_url = self._base_url+GenericOcrDataServiceProvider.API_POST_FILE_UPLOAD
                http = self._http
                response = http.request(
                    "post", api_url,
                    fields={
                        'file1': (os.path.basename(ocr_file), image_data),
                    }
                )
            self._ocr_file_id_list = [json.loads(
                response.data.decode('utf-8'))['response']['file_id']]

    def get_line_dict_from(self, pages: list = None,
                           line_dict_list: list = None, scaling_factors: list = None) -> list:
        """Returns list of line dictionary containing text and bbox values.

        Args:
            pages (list, optional):  Page to filter from given `doc_list`. Defaults to None.
            line_dict_list (list, optional): Existing line dictonary to filter certain page(s).
                - Defaults to None.
            scaling_factors (list, optional): value to scale up/down the bbox. First element is for
                vertical scaling factor and second is for horizontal scaling factor.
                - Defaults to [1.0, 1.0]

        Raises:
            Exception: Raises an Exception if the method is not implemented.

        Returns:
            list:  List of line dictionary containing the text, words and respective bbox values.
        """
        if not scaling_factors:
            scaling_factors = [1.0, 1.0]
        lines_structure = []
        if line_dict_list:
            if len(pages) == 0:
                return line_dict_list

            _ = [lines_structure.append(
                ocr_line_obj) for ocr_line_obj in line_dict_list if ocr_line_obj["page"] in pages]
            return lines_structure

        json_input = {
            "pages": pages,
            "scaling_factors": scaling_factors,
            "ocr_file_id_list": self._ocr_file_id_list
        }

        api_url = self._base_url + GenericOcrDataServiceProvider.API_POST_PARSER_LINES_STRUCTURE
        data_input = json.dumps(json_input)

        headers = {
            'Content-Type': 'application/json'
        }

        response = self._http.request(
            "post", api_url,
            body=data_input,
            headers=headers)
        lines_structure = json.loads(response.data.decode('utf-8'))['response']

        for line in lines_structure:
            invalid_keys = CommonUtil.get_invalid_keys(
                GenericOcrDataServiceProvider.RESPONSE_LINE_STRUCTURE_JSON_FORMAT, line)
            if len(invalid_keys) > 0:
                raise Exception(
                    f"Invalid keys found in config_params_dict: {invalid_keys}")

        return lines_structure

    def get_word_dict_from(self, pages: list = None,
                           word_dict_list: list = None, scaling_factors: list = None) -> list:
        return self.__get_word_dict_from(
            pages=pages, word_dict_list=word_dict_list, scaling_factors=scaling_factors)

    def __get_word_dict_from(self, line_obj=None, pages: list = None,
                             word_dict_list: list = None, scaling_factors: list = None) -> list:
        """Returns list of word dictionary containing text and bbox values.

        Args:
            line_obj ([any], optional): Existing line object to get words of it.
                - Defaults to None.
            pages (list, optional): Page to filter from given `doc_list`. Defaults to None.
            word_dict_list (list, optional): Existing word dictonary to filter certain page(s).
                - Defaults to None.
            scaling_factors (list, optional): value to scale up/down the bbox. First element is for
                vertical scaling factor and second is for horizontal scaling factor.
                - Defaults to [1.0, 1.0]

        Returns:
            list: List of word dictionary containing the text, bbox and conf values.
        """

        if not scaling_factors:
            scaling_factors = [1.0, 1.0]
        if line_obj:
            raise NotImplementedError

        word_structure = []
        if word_dict_list:
            if len(pages) == 0:
                return word_dict_list

            _ = [word_structure.append(
                ocr_word_obj) for ocr_word_obj in word_dict_list if ocr_word_obj["page"] in pages]
            return word_structure

        json_input = {
            "pages": pages,
            "scaling_factors": scaling_factors,
            "ocr_file_id_list": self._ocr_file_id_list
        }

        api_url = self._base_url + GenericOcrDataServiceProvider.API_POST_PARSER_WORD_STRUCTURE
        data_input = json.dumps(json_input)
        headers = {
            'Content-Type': 'application/json'
        }
        http = self._http
        response = http.request(
            "post", api_url,
            body=data_input,
            headers=headers)

        word_structure = json.loads(response.data.decode('utf-8'))['response']
        # to vaildate the keys are what this API expecting
        for word in word_structure:
            invalid_keys = CommonUtil.get_invalid_keys(
                GenericOcrDataServiceProvider.RESPONSE_WORD_STRUCTURE_JSON_FORMAT, word)
            if len(invalid_keys) > 0:
                raise Exception(
                    f"Invalid keys found in config_params_dict: {invalid_keys}")
        return word_structure

    def get_page_bbox_dict(self) -> list:
        """Returns pages wise bbox list

        Returns:
            list:  List of dictionary containing page num and its bbox values.
        """

        json_input = {

            "ocr_file_id_list": self._ocr_file_id_list
        }

        api_url = self._base_url+GenericOcrDataServiceProvider.API_POST_PARSER_PAGEBBOX
        data_input = json.dumps(json_input)
        headers = {
            'Content-Type': 'application/json'
        }
        http = self._http
        response = http.request(
            "post", api_url,
            body=data_input,
            headers=headers)
        page_bbox_dict_list = json.loads(
            response.data.decode('utf-8'))['response']
        for page_bbox in page_bbox_dict_list:
            invalid_keys = CommonUtil.get_invalid_keys(
                GenericOcrDataServiceProvider.RESPONSE_PAGE_BBOX_JSON_FORMAT, page_bbox)
            if len(invalid_keys) > 0:
                raise Exception(
                    f"Invalid keys found in config_params_dict: {invalid_keys}")
        return page_bbox_dict_list

    def __get_http_handle(self):
        http_proxy_url = os.environ.get("OCR_GEN_HTTP_PROXY_URL")
        http_proxy_auth = os.environ.get("OCR_GEN_HTTP_PROXY_AUTH")
        http = None
        if http_proxy_url:
            if http_proxy_auth:
                auth_header = {
                    'proxy-authorization': f'Basic {http_proxy_auth}'}
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE', proxy_headers=auth_header)
            else:
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE')
        else:
            http = urllib3.PoolManager()
        return http
