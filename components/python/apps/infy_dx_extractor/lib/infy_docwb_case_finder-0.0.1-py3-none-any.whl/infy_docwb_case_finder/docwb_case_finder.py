# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import copy
import logging
import traceback
from infy_docwb_case_finder.data.case_finder_req_data import CaseFinderReqData
from infy_docwb_case_finder.data.case_finder_res_data import CaseFinderResData
from infy_docwb_case_finder.data.config_param_data import ConfigParamData
from infy_docwb_case_finder.internal.common.common_util import CommonUtil
from infy_docwb_case_finder.internal.process.find_case_process import FindCaseProcess

ADDITIONAL_CONFIG_PARAM_DICT: dict = {
    'case_num_regex_pattern': "case# (\d*)"
}


class DocwbCaseFinder:
    def __init__(self, config_param_data: ConfigParamData, logger: logging.Logger = None,
                 log_level: int = None):
        self.__logger = CommonUtil.init_logger(logger, log_level)
        self.__find_case_proc_obj = FindCaseProcess(
            config_param_data, self.__logger)

    def query_for(self, req_data: CaseFinderReqData, additional_config_param_dict: ADDITIONAL_CONFIG_PARAM_DICT = None) -> CaseFinderResData:
        response_data = CaseFinderResData(None, None)
        if not additional_config_param_dict:
            additional_config_param_dict = {}
        additional_config_param_dict = {
            **ADDITIONAL_CONFIG_PARAM_DICT, **additional_config_param_dict}
        try:
            response_data = self.__find_case_proc_obj.query_for(
                req_data, additional_config_param_dict)
        except Exception:
            error = traceback.format_exc()
            self.__logger.error(error)
        return response_data
