# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class DocwbData:
    case_number: int
    create_dtm_from: str
    create_dtm_to: str
    task_status_cde: int
    task_status_operator: str

    def __init__(self, case_number: int = None, create_dtm_from: str = None,
                 create_dtm_to: str = None, task_status_cde: int = None,
                 task_status_operator: str = None) -> None:
        self.case_number = case_number
        self.create_dtm_from = create_dtm_from
        self.create_dtm_to = create_dtm_to
        self.task_status_cde = task_status_cde
        self.task_status_operator = task_status_operator


class EmailData:
    email_from: str
    from_id: str
    to: str
    to_id: str
    received_date_from: str
    received_date_to: str
    subject: str
    body_txt: str

    def __init__(self, email_from: str = None, from_id: str = None, to: str = None, to_id: str = None, received_date_from: str = None,
                 received_date_to: str = None, subject: str = None, body_txt: str = None) -> None:
        self.email_from = email_from
        self.from_id = from_id
        self.to = to
        self.to_id = to_id
        self.received_date_from = received_date_from
        self.received_date_to = received_date_to
        self.subject = subject
        self.body_txt = body_txt


class CaseFinderReqData:
    email: EmailData
    docwb: DocwbData

    def __init__(self, email: EmailData = None, docwb: DocwbData = None) -> None:
        self.email = email
        self.docwb = docwb
