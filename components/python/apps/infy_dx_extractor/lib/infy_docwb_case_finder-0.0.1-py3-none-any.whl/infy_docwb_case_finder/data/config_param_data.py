# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


class DocwbConfigData:
    end_point: str
    username: str
    password: str
    tenant_id: str

    def __init__(self, end_point: str, username: str, password: str, tenant_id: str) -> None:
        self.end_point = end_point
        self.username = username
        self.password = password
        self.tenant_id = tenant_id


class ConfigParamData:
    docwb_config_data: DocwbConfigData

    def __init__(self, docwb_config_data: DocwbConfigData) -> None:
        self.docwb_config_data = docwb_config_data
