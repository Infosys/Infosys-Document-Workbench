# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from typing import List


class PaginationData:
    current_page_number: int
    total_page_count: int
    total_item_count: int
    page_size: int

    def __init__(self, current_page_number: int, total_page_count: int, total_item_count: int, page_size: int) -> None:
        self.current_page_number = current_page_number
        self.total_page_count = total_page_count
        self.total_item_count = total_item_count
        self.page_size = page_size


class DocwbData:
    case_number: int
    task_status_cde: int
    task_status_txt: str
    create_dtm: str

    def __init__(self, case_number: int, task_status_cde: int, task_status_txt: str, create_dtm: str) -> None:
        self.case_number = case_number
        self.task_status_cde = task_status_cde
        self.task_status_txt = task_status_txt
        self.create_dtm = create_dtm


class RecordData:
    score: float
    docwb: DocwbData

    def __init__(self, score: float, docwb: DocwbData) -> None:
        self.score = score
        self.docwb = docwb


class ResponseData:
    records: List[RecordData]

    def __init__(self, records: List[RecordData]) -> None:
        self.records = records


class CaseFinderResData:
    response: ResponseData
    pagination: PaginationData

    def __init__(self, response: ResponseData, pagination: PaginationData) -> None:
        self.response = response
        self.pagination = pagination
