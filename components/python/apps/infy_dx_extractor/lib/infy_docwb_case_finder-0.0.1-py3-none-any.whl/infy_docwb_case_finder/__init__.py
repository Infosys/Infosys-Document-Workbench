# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

# --------------- Validate peer dependency is installed and throw exception ------------
try:
    import infy_docwb_sdk
except ImportError:
    raise Exception('Package `infy_docwb_sdk` is not installed')
