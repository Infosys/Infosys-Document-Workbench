# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import re
from infy_docwb_case_finder.data.case_finder_req_data import CaseFinderReqData
from infy_docwb_case_finder.data.case_finder_res_data import (
    CaseFinderResData, DocwbData, RecordData, ResponseData)
from infy_docwb_sdk import (auth_service, document_service)
from infy_docwb_sdk.data.doc_list_req_data import DocListReqData
from infy_docwb_sdk.data.doc_list_req_by_attr_data import DocListReqByAttrData

from infy_docwb_case_finder.data.config_param_data import ConfigParamData


class FindCaseProcess:
    def __init__(self, config_param_data: ConfigParamData, logger) -> None:
        self.__config_params_dict = config_param_data
        self.__logger = logger
        self.__document_service = None
        self.__init_docwb_sdk_service()

    def query_for(self, req_data: CaseFinderReqData, additional_config_param_dict: dict) -> CaseFinderResData:
        doc_list_req_data = DocListReqData(-1,
                                           task_status_cde=900, task_status_operator="<")
        doc_list_req_by_attr_data = DocListReqByAttrData(
            "", task_status_cde=900, task_status_operator="<")
        # ------ Email Data -------
        self.__get_query_param_from_email_data(
            req_data, doc_list_req_data, doc_list_req_by_attr_data, additional_config_param_dict)
        # ------ Docwb Data -------
        self.__get_query_param_from_docwb_data(
            req_data, doc_list_req_data, doc_list_req_by_attr_data, additional_config_param_dict)
        if doc_list_req_data.doc_id:
            res_result, pagination = self.__document_service.get_document_list(
                doc_list_req_data)
        elif doc_list_req_by_attr_data.search_criteria:
            res_result, pagination = self.__document_service.get_document_list_by_attribute(
                doc_list_req_by_attr_data)
        record_data_list = []
        for item in res_result:
            record_data_list.append(
                RecordData(1, DocwbData(item.get('docId'), item.get('taskStatusCde'),
                                        item.get('taskStatusTxt'), item.get('createDtm'))))
        response_data = CaseFinderResData(
            response=ResponseData(record_data_list), pagination=pagination)
        return response_data

    def __get_query_param_from_email_data(self, req_data: CaseFinderReqData, doc_list_req_data: DocListReqData,
                                          doc_list_req_by_attr_data: DocListReqByAttrData,
                                          additional_config_param_dict: dict):
        if req_data.email:
            search_criteria = ""
            if req_data.email.subject:
                case_num_regex_pattern = additional_config_param_dict.get(
                    'case_num_regex_pattern')
                match_val = re.search(
                    case_num_regex_pattern, req_data.email.subject.lower(), re.IGNORECASE)
                if match_val:
                    doc_list_req_data.doc_id = match_val.group(1)
            if req_data.email.from_id:
                search_criteria += f"20:{req_data.email.from_id}"
            doc_list_req_by_attr_data.search_criteria = search_criteria

    def __get_query_param_from_docwb_data(self, req_data: CaseFinderReqData, doc_list_req_data: DocListReqData,
                                          doc_list_req_by_attr_data: DocListReqByAttrData,
                                          additional_config_param_dict: dict):
        if req_data.docwb:
            if req_data.docwb.case_number:
                doc_list_req_data.doc_id = req_data.docwb.case_number
            if req_data.docwb.create_dtm_from:
                doc_list_req_data.from_event_dtm = req_data.docwb.create_dtm_from
            if req_data.docwb.create_dtm_to:
                doc_list_req_data.to_event_dtm = req_data.docwb.create_dtm_to
            if req_data.docwb.task_status_cde:
                doc_list_req_data.task_status_cde = req_data.docwb.task_status_cde
            if req_data.docwb.task_status_operator:
                doc_list_req_data.task_status_operator = req_data.docwb.task_status_operator

    def __init_docwb_sdk_service(self):
        auth_obj = auth_service.AuthService(logger=self.__logger)
        docwb_config = self.__config_params_dict.docwb_config_data
        auth_token = auth_obj.get_auth_token(
            docwb_config.end_point, docwb_config.username, docwb_config.password, docwb_config.tenant_id)
        if len(auth_token) == 0:
            raise Exception("Authentication failed!!")
        self.__logger.debug("Authentication successful")
        self.__document_service = document_service.DocumentService(
            auth_token, docwb_config.end_point, logger=self.__logger)
