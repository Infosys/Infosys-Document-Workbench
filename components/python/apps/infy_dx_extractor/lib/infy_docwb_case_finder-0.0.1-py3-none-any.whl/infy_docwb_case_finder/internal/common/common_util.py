# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


import logging


class CommonUtil:
    @classmethod
    def init_logger(cls, logger, log_level):
        _logger = logger
        log_level = log_level if log_level else logging.INFO
        if logger is None:
            logging.basicConfig(
                level=log_level,
                format='%(asctime)s.%(msecs)03d %(levelname)s docwb_case_finder - %(module)s - %(funcName)s: %(message)s'
            )
            logger = logging.getLogger()
            _logger = logger
            logger.info('log initialized')
        return _logger
