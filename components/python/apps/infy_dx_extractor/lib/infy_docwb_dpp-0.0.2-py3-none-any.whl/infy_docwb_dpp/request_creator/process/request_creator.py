# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import os
import json
from typing import List
import infy_dpp_sdk
from infy_dpp_sdk.data import *
from infy_dpp_sdk.data.document_data import DocumentData
from infy_dpp_sdk.data.processor_response_data import ProcessorResponseData

PROCESSEOR_CONTEXT_DATA_NAME = "request_creator"


class RequestCreator(infy_dpp_sdk.interface.IProcessor):

    def __init__(self) -> None:
        self.__logger = self.get_logger()
        self.__file_sys_handler = self.get_fs_handler()

    def do_execute(self, document_data: DocumentData, context_data: dict, config_data: dict) -> ProcessorResponseData:
        response_list = self.__get_document_data(config_data, context_data)
        return response_list[0]

    def do_execute_batch(self, document_data_list: List[DocumentData], context_data_list: List[dict], config_data: dict) -> List[ProcessorResponseData]:
        """For do_execute_batch refer to the IProcessor interface. 
        Here overriding exclusively for request creator alone."""
        return self.__get_document_data(config_data, context_data_list[0])

    def __get_document_data(self, config_data: dict, context_data: dict):

        response_list = []
        processor_config_data = config_data.get('RequestCreator', {})
        work_root_path = processor_config_data.get('work_root_path')
        request_file_path = context_data.get('docwb_preprocessor', {}).get(
            'request_file_path', None)
        extracter_request_file_path = context_data.get('docwb_extractor', {}).get(
            'request_file_path', None)
        if request_file_path:
            if request_file_path or os.path.isabs(request_file_path):
                request_json = json.loads(
                    self.__file_sys_handler.read_file(request_file_path))
                pipeline_request_json = self.__prepare_request_file(
                    request_json, request_file_path)
            else:
                self.__logger.error(
                    'Either Enable workflow or provide request file path')
            if request_json:
                req_id = request_json['records'][0]['doc_batch_id']
                request_file_write_path = f'{work_root_path}/{req_id}_indexer_request_file.json'
                self.__file_sys_handler.write_file(
                    request_file_write_path, json.dumps(pipeline_request_json, indent=4))
                self.__logger.info(
                    f'Request file written to {request_file_write_path}')

            for idx, work_file in enumerate(pipeline_request_json['working_file_path_list']):
                _context_data = self.__get_context_data(
                    context_data)
                _context_data[PROCESSEOR_CONTEXT_DATA_NAME] = {
                    "work_file_path": work_file,
                    "source": "docwb"
                }
                document_data = infy_dpp_sdk.data.DocumentData(
                    document_id=pipeline_request_json['doc_id_list'][idx], metadata=None)
                response_data = infy_dpp_sdk.data.ProcessorResponseData(
                    document_data=document_data, context_data=_context_data)
                response_list.append(response_data)
        if extracter_request_file_path:
            document_json_file_dir_list = json.loads(
                self.__file_sys_handler.read_file(extracter_request_file_path))['working_file_path_list']
            for idx, work_dir in enumerate(document_json_file_dir_list):
                all_files_list = self.__file_sys_handler.list_files(work_dir)
                document_file_path = [
                    x for x in all_files_list if x.endswith('processor_response_data.json')][0]
                # document_file_path = f'{work_dir}/document_data.json'
                document_json = json.loads(
                    self.__file_sys_handler.read_file(document_file_path))
                context_data = document_json.get('context_data', {})
                document_data = document_json.get('document_data', {})
                _context_data = self.__get_context_data(
                    context_data)
                _context_data['extracter_request'] = {
                    "work_file_path": document_file_path,
                    "source": "extracter"
                }
                response_data = infy_dpp_sdk.data.ProcessorResponseData(
                    document_data=document_data, context_data=_context_data)
                response_list.append(response_data)
        if len(response_list) < 1:
            response_list.append(infy_dpp_sdk.data.ProcessorResponseData(
                document_data=infy_dpp_sdk.data.DocumentData(),
                context_data={}
            ))
        return response_list

    def __prepare_request_file(self, request_json, request_file_path):
        doc_id_list = []
        records_list = request_json.get('records')
        root_path = self.__file_sys_handler.get_storage_root_uri().split(':', 1)[
            1].replace('//', '').replace('\\', '/')
        if ':' in root_path:
            drive = root_path.split(':', 1)[0]
            if drive == drive.lower():
                root_path = root_path.replace(drive, drive.upper(), 1)
        doc_work_loc_list = []
        for record in records_list:
            doc_id_list.append(record['doc_id'])
            # doc_work_location = os.path.dirname(
            #     record['doc_work_location']).replace(root_path, '')
            doc_work_location = os.path.relpath(
                os.path.dirname(record['doc_work_location']), root_path)
            # doc_copy_path = record['doc_copy_path'].replace(
            #     root_path, '')
            doc_copy_path = os.path.relpath(record['doc_copy_path'], root_path)
            # doc_work_location = os.path.dirname(
            #     record['doc_work_location']).replace(root_path, '')
            doc_work_loc_list.append(
                f'{doc_work_location}/{os.path.basename(doc_copy_path)}')
            self._copy_data(doc_copy_path, doc_work_location)
        new_request_json = {"doc_id_list": doc_id_list,
                            "working_file_path_list": doc_work_loc_list,
                            "prepro_response_json_path": request_file_path}
        return new_request_json

    def _copy_data(self, source, target):
        try:
            self.__file_sys_handler.copy_file(source, target)
            self.__logger.info(
                f'File {source} copied to {target} successfully')
        except Exception as e:
            self.__logger.error(
                f'Error while copying file from {source} to {target} : {e}')
            raise e

    def __get_context_data(self, context_data):
        if not context_data:
            return {}
        else:
            return context_data.copy()
