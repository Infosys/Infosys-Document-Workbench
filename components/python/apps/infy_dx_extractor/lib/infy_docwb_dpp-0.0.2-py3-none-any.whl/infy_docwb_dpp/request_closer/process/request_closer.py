# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import os
import json
import copy
import infy_dpp_sdk
from infy_dpp_sdk.data import *
from infy_dpp_sdk.data.document_data import DocumentData
from infy_dpp_sdk.data.processor_response_data import ProcessorResponseData

PROCESSEOR_CONTEXT_DATA_NAME = "request_closer"


class RequestCloser(infy_dpp_sdk.interface.IProcessor):

    def __init__(self) -> None:
        self.__logger = self.get_logger()
        self.__file_sys_handler = self.get_fs_handler()

    def do_execute(self, document_data: DocumentData, context_data: dict, config_data: dict) -> ProcessorResponseData:
        response_data = infy_dpp_sdk.data.ProcessorResponseData(
            document_data=document_data, context_data=context_data)
        doc_id = document_data.document_id
        if not doc_id:
            return response_data
        root_path = self.__file_sys_handler.get_storage_root_uri().split(':', 1)[
            1].replace('//', '').replace('\\', '/')
        processor_config_data = config_data.get('RequestCloser', {})
        prepro_request_file_path = context_data.get(
            'docwb_preprocessor').get('request_file_path')
        # TODO: Rashmi get correct root paths
        chunked_files_root_path = config_data.get(
            'SaveChunkDataParser', {}).get('chunked_files_root_path')
        encoded_files_root_path = config_data.get('DataEncoder', {}).get(
            'encoded_files_root_path')
        # ------ Create output document directory --------------
        request_id = os.path.basename(prepro_request_file_path).split('_')[0]
        indexer_output_path = os.path.join(
            f"{processor_config_data.get('output_root_path')}", f"{request_id}_indexer_response.json")
        # -------- Generate response json ----------------
        response_dict = self.__generate_response(
            prepro_request_file_path, chunked_files_root_path, encoded_files_root_path)

        # ------ Save document data in output location ------
        self.__file_sys_handler.write_file(
            indexer_output_path, json.dumps(response_dict, indent=4))

        context_data[PROCESSEOR_CONTEXT_DATA_NAME] = {
            "output_file_path": f"{root_path}/{indexer_output_path}",
            "source": "docwb"
        }
        response_data.document_data = document_data
        response_data.context_data = context_data
        return response_data

    def __generate_response(self, request_file_path, chunked_files_root_path, encoded_files_root_path):
        preprocessor_response_json = json.loads(
            self.__file_sys_handler.read_file(request_file_path))
        records_list = preprocessor_response_json['records']
        updated_records_list = []
        for record in records_list:
            updated_record = copy.deepcopy(record)
            doc_work_folder_id = record['doc_work_folder_id']
            chunked_files_path = f"{chunked_files_root_path}/{doc_work_folder_id}/"
            encoded_files_path = f"{encoded_files_root_path}/{doc_work_folder_id}/"
            workflow_list = copy.deepcopy(record['workflow'])
            workflow_list.append(
                {
                    "service_name": "infy_dx_indexer",
                    "service_version": "0.0.1"
                }
            )

            indexer_response = {
                # "config_file_path":config_file_path,
                "chunked_files_root_path": chunked_files_path,
                "encoded_files_root_path": encoded_files_path,
                # "request_file_path":complete_file_path
            }

            updated_record['workflow'] = workflow_list
            updated_record['indexer_response'] = indexer_response

            updated_records_list.append(updated_record)

        response_dict = {
            "service_name": "infy_dx_indexer",
            "service_version": "0.0.1",
            "records": updated_records_list
        }

        return response_dict
