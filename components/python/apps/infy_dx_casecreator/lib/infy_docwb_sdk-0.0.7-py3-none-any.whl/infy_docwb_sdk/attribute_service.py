# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
import logging
import requests
from infy_docwb_sdk.data import document_data
from infy_docwb_sdk.data import attachment_data
from infy_docwb_sdk.internal import attribute_helper
from infy_docwb_sdk.internal import docwb_sdk_constants


class AttributeService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger

        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_attributes(self, document_data_obj: document_data.DocumentData):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_ATTRIBUTES
        json_attachments = []
        attachments = document_data_obj.get_attachments()
        for attachment in attachments:
            attachment: attachment_data.AttachmentData
            json_attachments.append({
                'attachmentId': attachment.get_attachment_id(),
                'attributes': attribute_helper.AttributeHelper.build_attribute_array(attachment.get_attributes())
            })
        data_input = json.dumps([{
            'docId': document_data_obj.get_doc_id(),
            'attributes': attribute_helper.AttributeHelper.build_attribute_array(document_data_obj.get_attributes()),
            'attachments': json_attachments
        }])

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
        else:
            raise Exception(response_json['responseMsg'])

    def get_attachment_attributes(self, doc_id, origValue):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_ATTACHMENT_ATTRIBUTES + "?docId=" +\
            str(doc_id)+"&origValue=" + str(origValue)
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = ""
            if response_json['response'] is not None:
                result = response_json['response']
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])

    def get_document_attributes(self, doc_id):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_DOCUMENT_ATTRIBUTES + "?docId=" + \
            str(doc_id)
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = ""
            if response_json['response'] is not None:
                result = response_json['response']
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])

    def add_attribute_source(self, doc_id, record):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_ATTRIBUTE_SOURCE
        data_input = json.dumps({
            'docId': doc_id,
            'record': record
        })
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json;charset=UTF-8'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
            return response
        else:
            raise Exception(response_json['responseMsg'])

    def export_attributes(self, doc_id):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_EXPORT_ATTRIBUTES + "?docId=" + \
            str(doc_id)
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = ""
            if response_json['response'] is not None:
                result = response_json['response']
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])