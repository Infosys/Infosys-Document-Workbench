# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
import logging
import enum
import requests
from infy_docwb_sdk.data import document_data
from infy_docwb_sdk.data.doc_list_req_by_attr_data import DocListReqByAttrData
from infy_docwb_sdk.data.doc_list_req_data import DocListReqData
from infy_docwb_sdk.internal import attribute_helper
from infy_docwb_sdk.internal import docwb_sdk_constants
from infy_docwb_sdk.internal.infy_json_encoder import InfyJSONEncoder


class EnumEventType(enum.Enum):
    DOCUMENT_CREATED = 100
    ATTRIBUTES_EXTRACTED_PENDING = 150
    ATTRIBUTES_EXTRACTED = 200
    CASE_OPENED = 300
    CASE_ASSIGNED = 400
    ACTION_CREATED = 500
    ACTION_COMPLETED = 600
    EMAIL_SENT = 700
    CASE_CLOSED = 800


class EnumTaskStatusType(enum.Enum):
    UNDEFINED = 50
    YET_TO_START = 100
    IN_PROGRESS = 200
    ON_HOLD = 300
    FOR_YOUR_REVIEW = 400
    RETRY_LATER = 500
    COMPLETE = 900
    FAILED = 901


APP_USER_ID_NONE = 0
DocumentData = document_data.DocumentData


class DocumentService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger
        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_document_with_attributes(self, document_data_obj: DocumentData):
        doc_id = 0
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_DOCUMENT_ATTRIBUTES
        if not isinstance(document_data_obj, DocumentData):
            raise TypeError(
                'document_data_obj must be an instance of DocumentData')

        data_input = json.dumps({
            'docTypeCde': document_data_obj.get_doc_type_cde(),
            'docLocation': document_data_obj.get_doc_location(),
            'lockStatusCde': document_data_obj.get_lock_status_cde(),
            'queueNameCde': document_data_obj.get_queue_name_cde(),
            'attributes': attribute_helper.AttributeHelper.build_attribute_array(document_data_obj.get_attributes())
        })

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            if response_json['response'] is not None:
                if response_json['response']['docId'] is not None:
                    doc_id = response_json['response']['docId']
            self.__logger.debug(doc_id)
            return doc_id
        else:
            raise Exception(response_json['responseMsg'])

    def insert_document_event_type(self, doc_id, event_type):
        if not isinstance(event_type, EnumEventType):
            raise TypeError('event_type must be an instance of EventType Enum')
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_DOCUMENT_EVENT_TYPE
        data_input = json.dumps({
            'docId': doc_id,
            'eventTypeCde': event_type.value
        })

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] != 0:
            raise Exception(response_json['responseMsg'])

    def update_document_status(self, doc_id, task_status_type):
        if not isinstance(task_status_type, EnumTaskStatusType):
            raise TypeError(
                'task_status_type must be an instance of TaskStatusType Enum')
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_UPDATE_DOCUMENT_TASK_STATUS
        data_input = json.dumps({
            'docId': doc_id,
            'taskStatusCde': task_status_type.value
        })

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }

        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] != 0:
            raise Exception(response_json['responseMsg'])

    def assign_case(self, doc_id, app_user_id, app_user_login_id, prev_app_user_login_id):
        return self.reassign_case(doc_id, app_user_id, APP_USER_ID_NONE, app_user_login_id, prev_app_user_login_id)

    def reassign_case(self, doc_id, app_user_id, prev_app_user_id, app_user_login_id, prev_app_user_login_id):
        is_case_assigned: bool = False
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ASSIGN_CASE
        data_input = json.dumps([{
            'docId': doc_id,
            'appUserId': app_user_id,
            'appUserLoginId': app_user_login_id,
            'prevAppUserLoginId': prev_app_user_login_id,
            'prevAppUserId': prev_app_user_id
        }])

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }

        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            is_case_assigned = True
            return is_case_assigned
        else:
            raise Exception(response_json['responseMsg'])

    def _generate_query_params(self, params):
        query_params = ''
        for key, value in params.items():
            if value is not None:
                query_params += f'{key}={value}&'
        return query_params[:-1]

    def get_document_list(self, doc_list_req_data: DocListReqData):
        data_input = InfyJSONEncoder().convert_to_camel_object(doc_list_req_data)

        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_DOCUMENTS + "?" + \
            self._generate_query_params(data_input)

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = (None, None)
            if response_json['response'] is not None:
                result = (response_json['response'],
                          response_json['pagination'])
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])

    def get_document_list_by_attribute(self, doc_list_req_by_attr_data: DocListReqByAttrData):
        data_input = InfyJSONEncoder().convert_to_camel_object(doc_list_req_by_attr_data)

        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_DOCUMENT_BY_ATTRIBUTE + "?" + \
            self._generate_query_params(data_input)

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = (None, None)
            if response_json['response'] is not None:
                result = (response_json['response'],
                          response_json['pagination'])
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])

    def close_case(self, doc_id, app_user_id, queue_name_cde, app_user_login_id):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_DOCUMENT_CASE + \
            "?queueNameCde=" + str(queue_name_cde)
        data_input = json.dumps([{
            'docId': doc_id,
            'appUserId': app_user_id,
            'appUserLoginId': app_user_login_id,
        }])

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }

        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            is_case_closed = True
            return is_case_closed
        else:
            raise Exception(response_json['responseMsg'])
