# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
import logging
import requests
from infy_docwb_sdk.data import attachment_data
from infy_docwb_sdk.data import document_data
from infy_docwb_sdk.internal import docwb_sdk_constants


class AttachmentService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger
        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_attachment(self, document_data_obj: document_data.DocumentData, is_inline_image):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_ATTACHMENTS
        attachments = None
        if is_inline_image:
            attachments = document_data_obj.get_inline_attachments()
        else:
            attachments = document_data_obj.get_attachments()

        files = []
        file_part = 'file'
        i = 1
        extract_type_cde = None
        for attachment in attachments:
            attachment: attachment_data.AttachmentData
            files.append((file_part+str(i), (attachment.get_logical_name(), open(
                attachment.get_physical_path(), 'rb'), 'application/pdf')))
            i = i+1
            extract_type_cde = attachment.get_extract_type_cde()

        data_input = {
            'docId': document_data_obj.get_doc_id(),
            'extractTypeCde': extract_type_cde,
            'groupName': document_data_obj.get_group_name(),
            'isPrimary': document_data_obj.get_is_primary()
        }

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token
        }

        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input, files=files)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            response_array = response_json['response']
            self.__logger.debug(response_array)
            return response_array
        else:
            raise Exception(response_json['responseMsg'])

    def get_doc_attachment_list(self, doc_id):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_GET_DOCUMENT_ATTACHMENTS + \
            "?docId=" + str(doc_id)
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = ""
            if response_json['response'] is not None:
                result = response_json['response']
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])

    def add_atta_atta_relation(self, atta_rel_type_cde, attachment_id_1, attachment_id_2, doc_id):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ATTA_ATTA_REL

        data_input = json.dumps({
            "attaRelTypeCde": atta_rel_type_cde,
            "attachmentId1": attachment_id_1,
            "attachmentId2": attachment_id_2,
            "docId": doc_id
        })
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }

        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            attaAttaRelId = response_json['response']
            self.__logger.debug(attaAttaRelId)
            return attaAttaRelId
        else:
            raise Exception(response_json['responseMsg'])
