# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import base64
import json
import logging
import requests
from infy_docwb_sdk.internal import docwb_sdk_constants


class AuthService:
    def __init__(self, logger=None):
        self.__logger = logger
        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def get_auth_token(self, base_url, user_name, password, tenant_id):

        authorization = base64.b64encode(
            str(user_name+":"+password).encode("ascii")).decode("ascii")
        api_url = base_url + docwb_sdk_constants.DocwbSdkConstants().API_GET_AUTHORIZATION_TOKEN

        data_input = json.dumps({
            'authorization': 'Basic ' + authorization,
            'tenantId': tenant_id
        })

        headers = {
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            token = ""
            if response_json['response'] is not None:
                if response_json['response']['token'] is not None:
                    token = response_json['response']['token']
            return token
        else:
            raise Exception(response_json['responseMsg'])
