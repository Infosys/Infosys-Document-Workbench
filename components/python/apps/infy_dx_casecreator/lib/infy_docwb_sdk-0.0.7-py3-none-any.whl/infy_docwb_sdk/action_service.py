# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
import logging
from typing import List

import requests

from infy_docwb_sdk.data.action_req_data import ActionReqData
from infy_docwb_sdk.internal import docwb_sdk_constants
from infy_docwb_sdk.internal.infy_json_encoder import InfyJSONEncoder


class ActionService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger

        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_action(self, request_data_list: List[ActionReqData]):
        api_url = self.__base_url + docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_ACTION
        data_input = InfyJSONEncoder().convert_to_camel_str(request_data_list)
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
            return response
        else:
            raise Exception(response_json['responseMsg'])
