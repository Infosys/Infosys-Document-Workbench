# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


import json
import logging
import requests
from infy_docwb_sdk.internal import docwb_sdk_constants


class QueueService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger

        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_new_queue(self, doc_type_cde: int, queue_name_txt: str, queue_name_cde: int = 0):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_NEW_QUEUE

        data_input = json.dumps({
            'docTypeCde': doc_type_cde,
            'queueNameTxt': queue_name_txt,
            'queueNameCde': queue_name_cde
        }, indent=4)

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
            return response
        else:
            raise Exception(response_json['responseMsg'])

    def get_queue_list(self):
        api_url = self.__base_url + docwb_sdk_constants.DocwbSdkConstants().API_GET_QUEUE_LIST
        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        try:
            response = requests.request("GET", api_url, headers=headers)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            result = ""
            if response_json['response'] is not None:
                result = response_json['response']
            self.__logger.debug(result)
            return result
        else:
            raise Exception(response_json['responseMsg'])
