# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class AnnotationData:
    __value = None
    __label = None
    __occurrence_num = None
    __page = None
    __source_bbox = None
    __page_bbox = None

    def get_value(self):
        return self.__value

    def set_value(self, value):
        self.__value = value

    def get_label(self):
        return self.__label

    def set_label(self, label):
        self.__label = label

    def get_occurrence_num(self):
        return self.__occurrence_num

    def set_occurrence_num(self, occurrence_num):
        self.__occurrence_num = occurrence_num

    def set_page(self, page):
        self.__page = page

    def get_page(self):
        return self.__page

    def set_source_bbox(self, source_bbox):
        self.__source_bbox = source_bbox

    def get_source_bbox(self):
        return self.__source_bbox

    def set_page_bbox(self, page_bbox):
        self.__page_bbox = page_bbox

    def get_page_bbox(self):
        return self.__page_bbox
