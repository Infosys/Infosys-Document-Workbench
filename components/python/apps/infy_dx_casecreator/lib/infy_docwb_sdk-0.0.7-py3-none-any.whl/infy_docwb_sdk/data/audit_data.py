# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class AuditData:

    __entity_name = None
    __entity_value = None
    __audit_message = None
    __current_value = None
    __previous_value = None

    def get_entity_name(self):
        return self.__entity_name

    def set_entity_name(self, entity_name):
        self.__entity_name = entity_name

    def get_entity_value(self):
        return self.__entity_value

    def set_entity_value(self, entity_value):
        self.__entity_value = entity_value

    def get_audit_message(self):
        return self.__audit_message

    def set_audit_message(self, audit_message):
        self.__audit_message = audit_message

    def get_current_value(self):
        return self.__current_value

    def set_current_value(self, current_value):
        self.__current_value = current_value

    def get_previous_value(self):
        return self.__previous_value

    def set_previous_value(self, previous_value):
        self.__previous_value = previous_value

    # def __repr__(self):
    #     return 'Object: {}'.format('hello')

    # def toJSON(self):
    #     return json.dumps(self, default=lambda o: o.__dict__,
    #                       sort_keys=True, indent=4)
