# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from typing import List


class MappingData:
    attr_name_cde: int
    attr_name_txt: str
    param_name_cde: int
    param_value: str

    def __init__(self, attr_name_cde: int, attr_name_txt: str, param_name_cde: int, param_value: str) -> None:
        self.attr_name_cde = attr_name_cde
        self.attr_name_txt = attr_name_txt
        self.param_name_cde = param_name_cde
        self.param_value = param_value


class ActionData:
    action_name_cde: int
    mapping_list: List[MappingData]
    task_type_cde: int

    def __init__(self, action_name_cde: int, mapping_list: List[MappingData], task_type_cde: int) -> None:
        self.action_name_cde = action_name_cde
        self.mapping_list = mapping_list
        self.task_type_cde = task_type_cde


class ActionReqData:
    action_data_list: List[ActionData]
    doc_id: int

    def __init__(self, action_data_list: List[ActionData], doc_id: int) -> None:
        self.action_data_list = action_data_list
        self.doc_id = doc_id
