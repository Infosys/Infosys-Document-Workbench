# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from typing import List


class DocListReqData:
    queue_name_cde: int
    task_status_cde: int
    task_status_operator: str
    highest_event_type_cde: int
    highest_event_type_operator: str
    latest_event_type_cde: int
    latest_event_type_operator: str
    attr_name_cdes: List[int]
    attachment_attr_name_cdes: List[int]
    lock_status_cde: int
    doc_id: int
    page_number: int
    app_user_id: str
    sort_order: str
    document_name: str
    assigned_to: str
    assigned_to_key: str
    from_event_dtm: str
    to_event_dtm: str
    page_size: int
    sort_by_attr_name_cde: int
    is_pagination: bool

    def __init__(self, queue_name_cde: int, task_status_cde: int = None, task_status_operator: int = None,
                 highest_event_type_cde: int = None, highest_event_type_operator: int = None, latest_event_type_cde: int = None,
                 latest_event_type_operator: int = None, attr_name_cdes: List[int] = None, attachment_attr_name_cdes: List[int] = None,
                 lock_status_cde: int = None, doc_id: int = None, page_number: int = None, app_user_id: int = None, sort_order: int = None,
                 document_name: int = None, assigned_to: int = None, assigned_to_key: int = None, from_event_dtm: int = None,
                 to_event_dtm: int = None, page_size: int = None, sort_by_attr_name_cde: int = None, is_pagination: bool = False) -> None:
        self.queue_name_cde = queue_name_cde
        self.task_status_cde = task_status_cde
        self.task_status_operator = task_status_operator
        self.highest_event_type_cde = highest_event_type_cde
        self.highest_event_type_operator = highest_event_type_operator
        self.latest_event_type_cde = latest_event_type_cde
        self.latest_event_type_operator = latest_event_type_operator
        self.attr_name_cdes = attr_name_cdes
        self.attachment_attr_name_cdes = attachment_attr_name_cdes
        self.lock_status_cde = lock_status_cde
        self.doc_id = doc_id
        self.page_number = page_number
        self.app_user_id = app_user_id
        self.sort_order = sort_order
        self.document_name = document_name
        self.assigned_to = assigned_to
        self.assigned_to_key = assigned_to_key
        self.from_event_dtm = from_event_dtm
        self.to_event_dtm = to_event_dtm
        self.page_size = page_size
        self.sort_by_attr_name_cde = sort_by_attr_name_cde
        self.is_pagination = is_pagination
