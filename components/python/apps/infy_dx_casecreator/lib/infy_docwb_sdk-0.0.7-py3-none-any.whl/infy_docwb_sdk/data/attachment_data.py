# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class AttachmentData:
    __attachment_id = None
    __attributes = None
    __logical_name = None
    __physical_path = None
    __extract_type_cde = None
    __annotations = None

    def get_attachment_id(self):
        return self.__attachment_id

    def set_attachment_id(self, attachment_id):
        self.__attachment_id = attachment_id

    def get_attributes(self):
        return self.__attributes

    def set_attributes(self, attributes):
        self.__attributes = attributes

    def get_physical_path(self):
        return self.__physical_path

    def set_physical_path(self, physical_path):
        self.__physical_path = physical_path

    def get_logical_name(self):
        return self.__logical_name

    def set_logical_name(self, logical_name):
        self.__logical_name = logical_name

    def get_extract_type_cde(self):
        return self.__extract_type_cde

    def set_extract_type_cde(self, extract_type_cde):
        self.__extract_type_cde = extract_type_cde

    def get_annotations(self):
        return self.__annotations

    def set_annotations(self, annotations):
        self.__annotations = annotations
