# ===============================================================================================================#
# Copyright 2023 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from typing import List


class DocListReqByAttrData:
    search_criteria: str
    queue_name_cde: int
    task_status_cde: int
    task_status_operator: str
    page_number: int
    sort_order: str
    from_create_dtm: str
    to_create_dtm: str

    def __init__(self, search_criteria: str, queue_name_cde: int = None,
                 task_status_cde: int = None, task_status_operator: str = None, page_number: int = None, sort_order: str = None,
                 from_create_dtm: str = None, to_create_dtm: str = None,) -> None:
        self.search_criteria = search_criteria
        self.queue_name_cde = queue_name_cde
        self.from_create_dtm = from_create_dtm
        self.page_number = page_number
        self.to_create_dtm = to_create_dtm
        self.task_status_cde = task_status_cde
        self.task_status_operator = task_status_operator
        self.sort_order = sort_order
