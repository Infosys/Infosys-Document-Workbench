# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class AttributeData:
    __attr_name_cde = None
    __attr_name_txt = None
    __attr_value = None
    __extract_type_cde = None
    __confidence_pct = None
    __attributes = None

    def get_attr_name_cde(self):
        return self.__attr_name_cde

    def set_attr_name_cde(self, attr_name_cde):
        self.__attr_name_cde = attr_name_cde

    def get_attr_name_txt(self):
        return self.__attr_name_txt

    def set_attr_name_txt(self, attr_name_txt):
        self.__attr_name_txt = attr_name_txt

    def get_attr_value(self):
        return self.__attr_value

    def set_attr_value(self, attr_value):
        self.__attr_value = attr_value

    def get_extract_type_cde(self):
        return self.__extract_type_cde

    def set_extract_type_cde(self, extract_type_cde):
        self.__extract_type_cde = extract_type_cde

    def get_confidence_pct(self):
        return self.__confidence_pct

    def set_confidence_pct(self, confidence_pct):
        self.__confidence_pct = confidence_pct

    def get_attributes(self):
        return self.__attributes

    def set_attributes(self, attributes):
        self.__attributes = attributes
