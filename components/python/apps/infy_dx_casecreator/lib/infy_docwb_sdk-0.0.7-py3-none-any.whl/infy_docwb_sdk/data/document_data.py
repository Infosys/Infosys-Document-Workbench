# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


class DocumentData:
    __doc_type_cde = None
    __doc_location = None
    __lock_status_cde = None
    __queue_name_cde = None
    __attributes = None
    __attachments = None
    __doc_id = None
    __inline_attachments = None
    __annotations = None
    __group_name = None
    __is_primary = None

    def get_is_primary(self):
        return self.__is_primary

    def set_is_primary(self, is_primary):
        self.__is_primary = is_primary

    def get_group_name(self):
        return self.__group_name

    def set_group_name(self, group_name):
        self.__group_name = group_name

    def get_doc_type_cde(self):
        return self.__doc_type_cde

    def set_doc_type_cde(self, doc_type_cde):
        self.__doc_type_cde = doc_type_cde

    def get_doc_location(self):
        return self.__doc_location

    def set_doc_location(self, doc_location):
        self.__doc_location = doc_location

    def get_lock_status_cde(self):
        return self.__lock_status_cde

    def set_lock_status_cde(self, lock_status_cde):
        self.__lock_status_cde = lock_status_cde

    def get_queue_name_cde(self):
        return self.__queue_name_cde

    def set_queue_name_cde(self, queue_name_cde):
        self.__queue_name_cde = queue_name_cde

    def get_attributes(self):
        return self.__attributes

    def set_attributes(self, attributes):
        self.__attributes = attributes

    def get_attachments(self):
        return self.__attachments

    def set_attachments(self, attachments):
        self.__attachments = attachments

    def get_doc_id(self):
        return self.__doc_id

    def set_doc_id(self, doc_id):
        self.__doc_id = doc_id

    def get_inline_attachments(self):
        return self.__inline_attachments

    def set_inline_attachments(self, inline_attachments):
        self.__inline_attachments = inline_attachments

    def get_annotations(self):
        return self.__annotations

    def set_annotations(self, annotations):
        self.__annotations = annotations
