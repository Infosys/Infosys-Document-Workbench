# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from infy_docwb_sdk.data import annotation_data

AnnotationData = annotation_data.AnnotationData


class AnnotationHelper:

    @staticmethod
    def build_annotation_array(annotations):
        json_annotations = []
        if annotations:
            for annotation in annotations:
                if not isinstance(annotation, AnnotationData):
                    raise TypeError(
                        'annotation must be an instance of AnnotationData')
                annotation: AnnotationData
                json_annotations.append({
                    "label": annotation.get_label(),
                    "value": annotation.get_value(),
                    "occurrenceNum": annotation.get_occurrence_num(),
                    "page": annotation.get_page(),
                    "pageBbox": annotation.get_page_bbox(),
                    "sourceBbox": annotation.get_source_bbox()
                })
        return json_annotations
