# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

class DocwbSdkConstants():
    API_GET_AUTHORIZATION_TOKEN = "/api/v1/auth"
    API_GET_DOCUMENTS = "/api/v1/document"
    API_GET_DOCUMENT_BY_ATTRIBUTE = "/api/v1/document/attribute"
    API_GET_DOCUMENT_ATTACHMENTS = "/api/v1/attachment/doc"
    API_GET_ATTACHMENT_ATTRIBUTES = "/api/v1/attribute/attachment"
    API_GET_DOCUMENT_ATTRIBUTES = "/api/v1/attribute/document"
    API_GET_EXPORT_ATTRIBUTES = "/api/v1/attribute/export"
    API_GET_QUEUE_LIST = "/api/v1/queue"

    API_POST_ADD_DOCUMENT_ATTRIBUTES = "/api/v1/document"
    API_POST_ADD_DOCUMENT_EVENT_TYPE = "/api/v1/document/eventType"
    API_POST_UPDATE_DOCUMENT_TASK_STATUS = "/api/v1/document/taskstatus"
    API_POST_ADD_ATTRIBUTES = "/api/v1/attribute/add"
    API_POST_ASSIGN_CASE = "/api/v1/document/user"
    API_POST_ADD_ATTACHMENTS = "/api/v1/attachment/doc"
    API_POST_ADD_ANNOTATIONS = "/api/v1/annotation/add"
    API_POST_ADD_DOCUMENT_AUDIT = "/api/v1/audit/document"
    API_POST_ADD_ATTRIBUTE_SOURCE = "/api/v1/attribute/source"
    API_POST_ADD_NEW_QUEUE = "/api/v1/queue"
    API_POST_ASSIGN_QUEUE = "/api/v1/user/queue"
    API_POST_DOCUMENT_CASE = "/api/v1/document/case"
    API_POST_ADD_ACTION = "/api/v1/action"
    API_POST_ATTA_ATTA_REL = "/api/v1/attachment/attachment"
