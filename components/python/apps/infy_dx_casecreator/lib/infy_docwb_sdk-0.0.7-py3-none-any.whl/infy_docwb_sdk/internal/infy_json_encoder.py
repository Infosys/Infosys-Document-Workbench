# ===============================================================================================================#
# Copyright 2022 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import json
from json import JSONEncoder
from camel_converter import dict_to_camel


class InfyJSONEncoder(JSONEncoder):
    def default(self, o):
        return o.__dict__

    def convert_to_dict(self, json_str):
        return json.loads(json_str)

    def __convert_to_camel(self, obj):
        dict_obj = self.convert_to_dict(self.encode(obj))
        if isinstance(dict_obj, list):
            final_list = []
            for x in dict_obj:
                final_list.append(dict_to_camel(x))
            return final_list
        else:
            return dict_to_camel(dict_obj)

    def convert_to_camel_object(self, obj):
        return self.__convert_to_camel(obj)

    def convert_to_camel_str(self, obj):
        return json.dumps(self.__convert_to_camel(obj))
