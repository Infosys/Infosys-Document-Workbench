# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

from infy_docwb_sdk.data import attribute_data

AttributeData = attribute_data.AttributeData


class AttributeHelper:

    @staticmethod
    def build_attribute_array(attributes):

        json_attributes = []
        if attributes:
            for attribute in attributes:
                if not isinstance(attribute, AttributeData):
                    raise TypeError(
                        'attribute must be an instance of AttributeData')
                attribute: AttributeData
                json_attributes.append({
                    "attrNameCde": attribute.get_attr_name_cde(),
                    "attrValue": attribute.get_attr_value(),
                    "attrNameTxt": attribute.get_attr_name_txt(),
                    "extractTypeCde": attribute.get_extract_type_cde(),
                    "confidencePct": attribute.get_confidence_pct(),
                    "attributes": AttributeHelper.build_attribute_array(attribute.get_attributes())
                })
        return json_attributes
