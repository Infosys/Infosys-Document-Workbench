# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


import json
import logging
import requests
from infy_docwb_sdk.internal import docwb_sdk_constants


class UserService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger

        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_user_to_queue(self, app_user_id: int, queue_name_cde: int, app_user_login_id: str):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ASSIGN_QUEUE

        data_input = json.dumps({
            'appUserId': app_user_id,
            'appUserLoginId': app_user_login_id,
            'queueNameCde': queue_name_cde
        }, indent=4)

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception(
                'Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
            return response
        else:
            raise Exception(response_json['responseMsg'])
