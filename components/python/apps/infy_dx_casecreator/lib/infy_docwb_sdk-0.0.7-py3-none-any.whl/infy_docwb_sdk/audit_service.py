# ===============================================================================================================#
# Copyright 2020 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#


import json
import logging
import requests
from infy_docwb_sdk.internal import docwb_sdk_constants


class AuditService:
    def __init__(self, token, url, logger=None):
        self.__auth_token = token
        self.__base_url = url
        self.__logger = logger

        if logger is None:
            logging.basicConfig(
                level=logging.INFO, format='%(asctime)s.%(msecs)03d %(levelname)s'
                '%(module)s - %(funcName)s: %(message)s')
            logger = logging.getLogger()
            self.__logger = logger
            self.__logger.debug('log initialized')

    def add_document_audit(self, doc_id: int, audit_data_list: list):
        api_url = self.__base_url + \
            docwb_sdk_constants.DocwbSdkConstants().API_POST_ADD_DOCUMENT_AUDIT

        client_audit_data_list = []
        for audit_data_obj in audit_data_list:
            client_audit_data_list.append({
                "entityName": audit_data_obj.get_entity_name(),
                "entityValue": audit_data_obj.get_entity_value(),
                "auditMessage": audit_data_obj.get_audit_message(),
                "currentValue": audit_data_obj.get_current_value(),
                "previousValue": audit_data_obj.get_previous_value(),
            })

        data_input = json.dumps({
            'docId': doc_id,
            'auditDataList': client_audit_data_list
        }, indent=4)

        headers = {
            'Authorization': 'Bearer ' + self.__auth_token,
            'Content-Type': 'application/json'
        }
        self.__logger.debug("Request json: ")
        self.__logger.debug(data_input)
        try:
            response = requests.request(
                "POST", api_url, headers=headers, data=data_input)
        except Exception as e:
            raise Exception('Error occured while making REST API call', e)

        if not response.ok:
            message = f'Received error response. Http Response '
            message += f'[Status Code = {response.status_code}, Reason = {response.reason}]'
            raise Exception(message)

        response_json = response.json()
        if response_json['responseCde'] == 0:
            self.__logger.debug(response.status_code)
            return response
        else:
            raise Exception(response_json['responseMsg'])
