# ===============================================================================================================#
# Copyright 2021 Infosys Ltd.                                                                                    #
# Use of this source code is governed by Apache License Version 2.0 that can be found in the LICENSE file or at  #
# http://www.apache.org/licenses/                                                                                #
# ===============================================================================================================#

import os
import json
import urllib3
import urllib.parse
import traceback
import logging
import copy
import imageio
import pytesseract
from infy_ocr_generator.interface.data_service_provider_interface import (
    GENERATE_API_RES_STRUCTURE, DataServiceProviderInterface,
    DOC_DATA)


class GenericOcrDataServiceProvider(DataServiceProviderInterface):
    """Implementation of DataServiceProvider for Generic OCR"""
    API_POST_FILE_UPLOAD = "/api/v1/file/upload"
    API_POST_OCR_DATA_LIST = "/api/v1/ocr/generate"
    API_POST_FILE_DOWNLOAD = "/api/v1/file/download"

    def __init__(self, base_url: str, config_params_dict: any,
                 output_dir: str = None,
                 output_to_supporting_folder: bool = False,
                 overwrite: bool = False,
                 logger: logging.Logger = None,
                 log_level: int = None):
        """Creates an instance of Generic Ocr Data Service Provider

        Args:
            config_params_dict (CONFIG_PARAMS_DICT): Provider CONFIG values.
            output_dir (str, optional): Directory to generate OCR file,
                if not given will generate into same file location. Defaults to None.
            output_to_supporting_folder (bool, optional): If True, OCR file will be generated to
                same file location but into supporting folder named `* _files`. Defaults to False.
            overwrite (bool, optional): If True, existing OCR file will be overwritten. Defaults to False.
            logger (logging.Logger, optional): logger object. Defaults to None.
            log_level (int, optional):log level. Defaults to None.

        Raises:
            FileNotFoundError: Raises an error if the file is not found.
        """
        super(GenericOcrDataServiceProvider,
              self).__init__(logger, log_level)

        if output_dir and not os.path.exists(output_dir):
            raise FileNotFoundError(f"{output_dir} not found")

        self.output_dir = output_dir
        self.output_to_supporting_folder = output_to_supporting_folder
        self.overwrite = overwrite
        self._base_url = base_url
        self._http = self.__get_http_handle()
        self._file_data_list = []

    def submit_request(self, doc_data_list: [DOC_DATA]) -> list:
        """API to submit tesseract ocr data service request for asynchorouns call

        Args:
            doc_data_list ([DOC_DATA]): List of input documents. e.g, ['c:/1.jpg','c:/1.pdf']

        Raises:
            NotImplementedError: Raises an error if the method is not implemented

        Returns:
            list: [SUB_RE_API_STRUCTURE]
        """
        raise NotImplementedError

    def receive_response(self, submit_req_response_list: list, rerun_unsucceeded_mode: bool = False) -> list:
        """API of tesseract ocr data service to Received response of asynchorouns call submit request.

        Args:
            submit_req_response_list (list): Response structure of `submit_request` api
            rerun_unsucceeded_mode (bool, optional): Enabling this mode and passing same request
             -will rerun for unsuccessful call. Defaults to False.

        Raises:
            NotImplementedError: Raises an error if the method is not implemented.

        Returns:
            list: [SUB_RE_API_STRUCTURE]
        """
        raise NotImplementedError

    def generate(self, doc_data_list: [DOC_DATA] = None, api_response_list: list = None) -> list:
        """API to generate OCR based on OCR provider given

        Args:
            doc_data_list ([DOC_DATA], optional): Use these input files to
                -implement technique and generate output files. Defaults to None.
            api_response_list (list, optional): API response will be generated into output file. Defaults to None.

        Returns:
            list: List of generated ocr file path.
        """
        try:
            #----------------- to upload image file api call----------------#
            for doc in doc_data_list:
                with open(doc['doc_path'], "rb") as reader:
                    image_data = reader.read()
                api_url = self._base_url+GenericOcrDataServiceProvider.API_POST_FILE_UPLOAD
                http = self._http
                response = http.request(
                    "post", api_url,
                    fields={
                        'file1': (os.path.basename(doc['doc_path']), image_data),
                    }
                )
                self._file_data_list.append({"file_id": json.loads(response.data.decode('utf-8'))['response']['file_id'],
                                             "pages": doc['pages']})
            #------------------below is generate API call-----------------------------#
            json_input = {
                "file_data_list": self._file_data_list
            }

            ocr_list = []

            api_url = self._base_url + GenericOcrDataServiceProvider.API_POST_OCR_DATA_LIST
            data_input = json.dumps(json_input)

            headers = {
                'Content-Type': 'application/json'
            }

            response = self._http.request(
                "post", api_url,
                body=data_input,
                headers=headers)

            file_id = json.loads(response.data.decode(
                'utf-8'))['response']['file_id']
            #---------------download file -------------------#

            api_url = self._base_url+GenericOcrDataServiceProvider.API_POST_FILE_DOWNLOAD
            http = self._http
            data_input = {
                "file_id": file_id
            }
            data = urllib.parse.urlencode(data_input)

            response = http.request(
                "post", api_url,
                body=data
            )
            save_file_path = self.output_dir + '/' + \
                response.headers.get('content-disposition').split('=')[1]

            with open(save_file_path, 'ab') as f:
                f.write(response.data)
        except Exception as ex:
            return ex
        return save_file_path

    def __get_http_handle(self):
        http_proxy_url = os.environ.get("OCR_GEN_HTTP_PROXY_URL")
        http_proxy_auth = os.environ.get("OCR_GEN_HTTP_PROXY_AUTH")
        http = None
        if http_proxy_url:
            if http_proxy_auth:
                auth_header = {
                    'proxy-authorization': f'Basic {http_proxy_auth}'}
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE', proxy_headers=auth_header)
            else:
                http = urllib3.ProxyManager(
                    http_proxy_url, cert_reqs='CERT_NONE')
        else:
            http = urllib3.PoolManager()
        return http
