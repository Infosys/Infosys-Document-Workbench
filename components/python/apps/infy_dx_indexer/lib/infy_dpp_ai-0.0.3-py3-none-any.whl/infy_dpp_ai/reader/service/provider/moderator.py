# ===============================================================================================================#
# (C) 2024 Infosys Limited, Bangalore, India. All Rights Reserved.                                               #
# Version: 1.0                                                                                                   #
#                                                                                                                #
# Except for any open source software components embedded in this Infosys proprietary software program           #
# ("Program"), this Program is protected by copyright laws, international treaties and other pending or          #
# existing intellectual property rights in India, the United States and other countries. Except as expressly     #
# permitted, any unauthorized reproduction, storage, transmission in any form or by any means (including         #
# without limitation electronic, mechanical, printing, photocopying, recording or otherwise), or any             #
# distribution of this Program, or any portion of it, may result in severe civil and criminal penalties, and will#
# be prosecuted to the maximum extent possible under the law.                                                    #
# ===============================================================================================================#

from pydantic import BaseModel
import requests


class ModeratorConfig(BaseModel):
    """Domain class"""
    api_url: str = None


class Moderator():
    """Class to perform moderation"""
    # api_url: str = None

    def perform_moderation_checks(self, moderation_config, moderation_payload):
        """Method to perform moderation checks"""
        response = requests.post(
            moderation_config.get('api_url'), json=moderation_payload, headers=None,
            verify=False, timeout=180)
        result = response.json()
        return result.get('moderationResults')
